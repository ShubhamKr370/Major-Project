import os

def load_smiles(file_path):
    """Loads SMILES strings from a file."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    smiles_list = []
    with open(file_path, 'r') as f:
        for line in f:
            sm = line.strip()
            if sm:
                smiles_list.append(sm)
    return smiles_list
