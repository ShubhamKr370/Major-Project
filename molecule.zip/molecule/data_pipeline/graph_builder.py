import torch
from rdkit import Chem

# Expanded Atom Map for better representation
ATOM_MAP = {
    'C': 0, 'O': 1, 'N': 2, 'F': 3, 'P': 4, 'S': 5, 'Cl': 6, 'Br': 7, 'I': 8
}

def mol_to_graph(smiles, max_atoms=50):
    """Converts SMILES to node features and edge indices."""
    mol = Chem.MolFromSmiles(smiles)
    if not mol:
        return None, None

    # Node features (Atom types)
    atoms = []
    for atom in mol.GetAtoms():
        symbol = atom.GetSymbol()
        atoms.append(ATOM_MAP.get(symbol, len(ATOM_MAP))) # len(ATOM_MAP) for 'Other'

    # Edge indices (Bonds)
    edges = []
    for bond in mol.GetBonds():
        start, end = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        # Bi-directional edges for GNN
        edges.append([start, end])
        edges.append([end, start])

    node_features = torch.tensor(atoms, dtype=torch.long)
    if edges:
        edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
    else:
        edge_index = torch.empty((2, 0), dtype=torch.long)

    return node_features, edge_index
