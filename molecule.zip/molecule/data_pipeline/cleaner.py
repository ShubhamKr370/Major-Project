from rdkit import Chem

def validate_smiles(smiles_list):
    """Filters out invalid SMILES using RDKit."""
    valid_smiles = []
    for sm in smiles_list:
        if Chem.MolFromSmiles(sm):
            valid_smiles.append(sm)
    return valid_smiles

def canonicalize_smiles(smiles):
    """Converts SMILES to its canonical form."""
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        return Chem.MolToSmiles(mol, canonical=True)
    return None
