import torch
from torch.utils.data import Dataset
from .graph_builder import mol_to_graph

class MoleculeGraphDataset(Dataset):
    def __init__(self, smiles_list, max_nodes=50):
        self.smiles_list = smiles_list
        self.max_nodes = max_nodes
        
        # Pre-process graphs for speed
        self.graphs = []
        for sm in smiles_list:
            nodes, edges = mol_to_graph(sm)
            if nodes is not None:
                # Pad nodes to max_nodes
                padded_nodes = torch.zeros(max_nodes)
                n = min(len(nodes), max_nodes)
                padded_nodes[:n] = nodes[:n]
                
                # We store padded nodes for dataloader stacking
                self.graphs.append((padded_nodes, edges))

    def __len__(self):
        return len(self.graphs)

    def __getitem__(self, idx):
        nodes, edges = self.graphs[idx]
        # Return properly shaped tensors: [max_nodes, 1]
        return nodes.unsqueeze(-1).float(), edges
