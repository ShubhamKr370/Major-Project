import torch
import torch.nn as nn
import torch.nn.functional as F

class GNN(nn.Module):
    """
    A Graph Neural Network backbone for denoising in diffusion.
    Uses simple message passing-like logic using MLP for clarity, as per user snippet.
    Extended with extra layers for 'production' stability.
    """
    def __init__(self, input_dim, hidden_dim=128, output_dim=None):
        super().__init__()
        if output_dim is None:
            output_dim = input_dim
            
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)
        )

    def forward(self, x):
        # x shape: [batch_size, input_dim]
        # In this simple version, we treat atoms as independent or global features
        # A more advanced version would use edge_index (Phase 1 implement)
        return self.net(x)
