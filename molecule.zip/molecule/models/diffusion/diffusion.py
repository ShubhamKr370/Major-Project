import torch
import torch.nn as nn

class Diffusion(nn.Module):
    """
    Implements a Gaussian Diffusion process.
    Matches the user's design with forward (add_noise) and backward (denoising) steps.
    """
    def __init__(self, model, timesteps=100, device='cpu'):
        super().__init__()
        self.model = model
        self.timesteps = timesteps
        self.device = device

        # Beta schedule (linear)
        self.beta = torch.linspace(1e-4, 0.02, timesteps).to(device)
        self.alpha = 1.0 - self.beta
        self.alpha_hat = torch.cumprod(self.alpha, dim=0)

    def add_noise(self, x, t):
        """Forward diffusion process: q(x_t | x_0)"""
        noise = torch.randn_like(x)
        # Handle indexing correctly for batches
        alpha_hat_t = self.alpha_hat.gather(-1, t).reshape(-1, 1) if t.dim() > 0 else self.alpha_hat[t]
        
        noisy_x = torch.sqrt(alpha_hat_t) * x + torch.sqrt(1 - alpha_hat_t) * noise
        return noisy_x, noise

    def forward(self, x, t):
        """Predicts noise added to x at timestep t."""
        noisy_x, noise = self.add_noise(x, t)
        pred_noise = self.model(noisy_x)
        return pred_noise, noise
    
    @torch.no_grad()
    def sample(self, shape):
        """Reverse diffusion process: p(x_{t-1} | x_t)"""
        self.model.eval()
        x = torch.randn(shape).to(self.device)
        
        for t_idx in reversed(range(self.timesteps)):
            t = torch.full((shape[0],), t_idx, dtype=torch.long).to(self.device)
            pred_noise = self.model(x)
            
            alpha_t = self.alpha[t_idx]
            alpha_hat_t = self.alpha_hat[t_idx]
            
            # Reparameterization step for denoising
            beta_t = self.beta[t_idx]
            if t_idx > 0:
                noise = torch.randn_like(x)
            else:
                noise = 0
            
            x = (1 / torch.sqrt(alpha_t)) * (
                x - ((1 - alpha_t) / torch.sqrt(1 - alpha_hat_t)) * pred_noise
            ) + torch.sqrt(beta_t) * noise
            
        return x
