import argparse
import torch
from torch.utils.data import DataLoader

from data_pipeline.loader import load_smiles
from data_pipeline.cleaner import validate_smiles
from data_pipeline.dataset import MoleculeGraphDataset
from models.diffusion.diffusion import Diffusion
from models.gnn.gnn_model import GNN
from training.trainer import Trainer
from generation.sampler import MoleculeGenerator
from evaluation.validity import check_validity
from utils.helpers import set_seed, get_logger

def main():
    parser = argparse.ArgumentParser(description="Molecule Generation System")
    parser.add_argument("--task", type=str, default="train", choices=["train", "generate"])
    parser.add_argument("--model", type=str, default="diffusion", choices=["diffusion", "transformer"])
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--batch_size", type=int, default=8)
    args = parser.parse_args()

    set_seed(42)
    logger = get_logger("MGS")
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # 1. Data Pipeline
    logger.info("Loading and cleaning data...")
    raw_smiles = load_smiles("data/raw/zinc.smiles")
    clean_smiles = validate_smiles(raw_smiles)
    
    dataset = MoleculeGraphDataset(clean_smiles)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True)

    # 2. Model Initialization
    logger.info(f"Initializing {args.model} model on {device}...")
    if args.model == "diffusion":
        backbone = GNN(input_dim=1) # Simple 1D input for this demo
        model = Diffusion(backbone, device=device)
    else:
        # Transformer placeholder
        vocab_size = 50 # Example
        from models.transformer.model import TransformerModel
        model = TransformerModel(vocab_size)

    # 3. Task Execution
    if args.task == "train":
        logger.info("Starting training...")
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
        trainer = Trainer(model, optimizer, device=device)
        for epoch in range(args.epochs):
            loss = trainer.train_epoch(loader, model_type=args.model)
            logger.info(f"Epoch {epoch+1}/{args.epochs} - Loss: {loss:.4f}")
            
    elif args.task == "generate":
        logger.info("Generating molecules...")
        generator = MoleculeGenerator(model, model_type=args.model, device=device)
        samples = generator.generate(num_samples=10, node_dim=1)
        smiles = generator.to_smiles(samples)
        
        validity = check_validity(smiles)
        logger.info(f"Generated SMILES: {smiles}")
        logger.info(f"Validity: {validity:.2%}")

if __name__ == "__main__":
    main()
