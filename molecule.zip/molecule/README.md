# Molecule Generation System

A Transformer + Diffusion hybrid system for generating chemically valid molecules.

## Architecture

- **Transformer**: SMILES sequence generation.
- **Diffusion**: Graph-based structure generation.
- **RDKit**: Chemical validation and property evaluation.

## Getting Started

1.  Install dependencies: `pip install -r requirements.txt`
2.  Prepare data: Place SMILES strings in `data/raw/zinc.smiles`.
3.  Run training: `python run.py --model diffusion`
4.  Generate: `python run.py --task generate --model diffusion`

## Folder Structure

Refer to the implementation plan for detailed module descriptions.
