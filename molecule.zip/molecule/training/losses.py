import torch
import torch.nn as nn

def diffusion_loss(model, x, t):
    """Simple MSE loss for diffusion training."""
    pred_noise, noise = model(x, t)
    return nn.functional.mse_loss(pred_noise, noise)

def cross_entropy_loss(logits, targets):
    """Cross-entropy loss for Transformer training."""
    return nn.functional.cross_entropy(logits.transpose(1, 2), targets)
