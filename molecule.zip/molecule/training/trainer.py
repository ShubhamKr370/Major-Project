import torch
import torch.nn as nn
from tqdm import tqdm

class Trainer:
    """
    Unified trainer for Diffusion and Transformer models.
    """
    def __init__(self, model, optimizer, device='cpu'):
        self.model = model
        self.optimizer = optimizer
        self.device = device
        self.model.to(device)

    def train_epoch(self, dataloader, model_type='diffusion'):
        self.model.train()
        total_loss = 0
        
        pbar = tqdm(dataloader, desc=f"Training {model_type}")
        for batch in pbar:
            self.optimizer.zero_grad()
            
            if model_type == 'diffusion':
                # batch is (nodes, edges)
                x, _ = batch 
                x = x.to(self.device)
                t = torch.randint(0, self.model.timesteps, (x.size(0),), device=self.device)
                
                pred_noise, noise = self.model(x, t)
                loss = nn.functional.mse_loss(pred_noise, noise)
                
            elif model_type == 'transformer':
                # batch is tokenized SMILES (placeholder)
                x = batch.to(self.device)
                # Next token prediction
                logits = self.model(x[:, :-1])
                loss = nn.functional.cross_entropy(logits.transpose(1, 2), x[:, 1:])
            
            loss.backward()
            self.optimizer.step()
            
            total_loss += loss.item()
            pbar.set_postfix(loss=loss.item())
            
        return total_loss / len(dataloader)
