from rdkit import Chem

def check_validity(smiles_list):
    """Returns the fraction of valid SMILES in a list."""
    if not smiles_list:
        return 0.0
    valid = [sm for sm in smiles_list if Chem.MolFromSmiles(sm)]
    return len(valid) / len(smiles_list)

def check_novelty(generated_smiles, training_smiles):
    """Returns the fraction of generated SMILES not present in the training set."""
    if not generated_smiles:
        return 0.0
    novel = [sm for sm in generated_smiles if sm not in training_smiles]
    return len(novel) / len(generated_smiles)

def check_uniqueness(smiles_list):
    """Returns the fraction of unique SMILES in a list."""
    if not smiles_list:
        return 0.0
    unique = set(smiles_list)
    return len(unique) / len(smiles_list)
