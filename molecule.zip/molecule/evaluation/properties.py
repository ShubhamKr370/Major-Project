from rdkit import Chem
from rdkit.Chem import QED, Descriptors

def calculate_qed(smiles):
    """Calculates Quantitative Estimate of Drug-likeness."""
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        return QED.qed(mol)
    return 0.0

def calculate_logp(smiles):
    """Calculates Octanol-water partition coefficient."""
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        return Descriptors.MolLogP(mol)
    return 0.0

def get_properties(smiles_list):
    """Returns a list of properties for a batch of molecules."""
    props = []
    for sm in smiles_list:
        props.append({
            'smiles': sm,
            'qed': calculate_qed(sm),
            'logp': calculate_logp(sm)
        })
    return props
